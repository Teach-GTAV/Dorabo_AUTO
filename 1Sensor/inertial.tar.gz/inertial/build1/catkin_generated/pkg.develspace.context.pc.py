# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/program/ugv_ws/src/ugv_master/1Sensor/inertial/build1/devel/include;/program/ugv_ws/src/ugv_master/1Sensor/inertial/include".split(';') if "/program/ugv_ws/src/ugv_master/1Sensor/inertial/build1/devel/include;/program/ugv_ws/src/ugv_master/1Sensor/inertial/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs;ugv_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-linertial".split(';') if "-linertial" != "" else []
PROJECT_NAME = "inertial"
PROJECT_SPACE_DIR = "/program/ugv_ws/src/ugv_master/1Sensor/inertial/build1/devel"
PROJECT_VERSION = "0.0.0"
